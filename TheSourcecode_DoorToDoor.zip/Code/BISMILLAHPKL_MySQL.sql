CREATE DATABASE db_logistik;
USE db_logistik;

-- Tabel Admin
CREATE TABLE Admin (
    id_Admin INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(100),
    password VARCHAR(100),
    nama VARCHAR(100)
);

-- Tabel User
CREATE TABLE User (
    id_User INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(100),
    password VARCHAR(100),
    nama VARCHAR(100),
    role ENUM('CS', 'Driver', 'Karyawan'),
    id_Admin INT,
    FOREIGN KEY (id_Admin) REFERENCES Admin(id_Admin)
);

-- Tabel Laporan
CREATE TABLE Laporan (
    id_Laporan INT PRIMARY KEY AUTO_INCREMENT,
    jenis_laporan VARCHAR(100),
    tanggal_buat DATE,
    isi_laporan TEXT,
    id_Admin INT,
    FOREIGN KEY (id_Admin) REFERENCES Admin(id_Admin)
);

-- Tabel Data_Rute
CREATE TABLE Data_Rute (
    id_Rute INT PRIMARY KEY AUTO_INCREMENT,
    kota_asal VARCHAR(100),
    kota_tujuan VARCHAR(100),
    kode_cabang VARCHAR(50),
    estimasi_waktu TIME,
    id_Admin INT,
    FOREIGN KEY (id_Admin) REFERENCES Admin(id_Admin)
);

-- Tabel Permintaan_Pickup
CREATE TABLE Permintaan_Pickup (
    id_Permintaan INT PRIMARY KEY AUTO_INCREMENT,
    nama_pengirim VARCHAR(100),
    alamat_pengirim TEXT,
    nama_penerima VARCHAR(100),
    alamat_penerima TEXT,
    waktu_permintaan DATETIME,
    status_permintaan VARCHAR(50),
    id_User INT,
    FOREIGN KEY (id_User) REFERENCES User(id_User)
);

-- Tabel Jadwal_Pickup
CREATE TABLE Jadwal_Pickup (
    id_Jadwal INT PRIMARY KEY AUTO_INCREMENT,
    tanggal_pickup DATE,
    jam_pickup TIME,
    status_pickup VARCHAR(50),
    id_User INT,
    id_permintaan INT,
    FOREIGN KEY (id_User) REFERENCES User(id_User),
    FOREIGN KEY (id_permintaan) REFERENCES Permintaan_Pickup(id_Permintaan)
);

-- Tabel Barang_Proses
CREATE TABLE Barang_Proses (
    id_Barang INT PRIMARY KEY AUTO_INCREMENT,
    jenis_barang VARCHAR(100),
    berat_barang DECIMAL(10,2),
    status_barang VARCHAR(50),
    waktu_sortir DATETIME,
    id_User INT,
    id_Permintaan INT,
    FOREIGN KEY (id_User) REFERENCES User(id_User),
    FOREIGN KEY (id_Permintaan) REFERENCES Permintaan_Pickup(id_Permintaan)
);

-- Tabel Pengantaran
CREATE TABLE Pengantaran (
    id_Pengantaran INT PRIMARY KEY AUTO_INCREMENT,
    status_pengantaran VARCHAR(50),
    waktu_berangkat DATETIME,
    waktu_terima DATETIME,
    bukti_terima TEXT,
    id_User INT,
    id_Barang INT,
    FOREIGN KEY (id_User) REFERENCES User(id_User),
    FOREIGN KEY (id_Barang) REFERENCES Barang_Proses(id_Barang)
);
admin`db_dbmdoor-todoor``db_dbmdoor-todoor`barang_prosesdata_rutejadwal_pickuplaporanloginpengantaranpermintaan_pickuprute_data`user`users